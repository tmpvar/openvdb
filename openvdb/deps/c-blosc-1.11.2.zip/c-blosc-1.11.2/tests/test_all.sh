#*********************************************************************
#  Blosc - Blocked Shuffling and Compression Library
#
#  Unit tests for basic features in Blosc.
#
#  Creation date: 2010-06-07
#  Author: Francesc Alted <francesc@blosc.org>
#
#  See LICENSES/BLOSC.txt for details about copyright and rights to use.
#**********************************************************************

for exe in $(ls *.exe); do
    ./$exe
done
